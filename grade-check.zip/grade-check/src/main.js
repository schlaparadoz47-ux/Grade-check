/* ============================================================
   Grade-Check Vault — main.js
   Vollständige App-Logik. Läuft als Vite-Modul (Web + Capacitor).
   Kein Framework, keine externen Laufzeit-Abhängigkeiten außer
   den optionalen Capacitor-Plugins (graceful fallback im Browser).
   ============================================================ */
"use strict";

/* ---------- Optionale Capacitor-Plugins (nur in der nativen App) ---------- */
let Cap = { native:false, Camera:null, Filesystem:null };
async function initCapacitor(){
  try{
    const core = await import("@capacitor/core").catch(()=>null);
    if(core && core.Capacitor && core.Capacitor.isNativePlatform && core.Capacitor.isNativePlatform()){
      Cap.native = true;
      Cap.Camera = (await import("@capacitor/camera").catch(()=>null))?.Camera || null;
      Cap.Filesystem = (await import("@capacitor/filesystem").catch(()=>null)) || null;
    }
  }catch(e){ /* im Browser nicht vorhanden – egal */ }
}

/* ---------- Konstanten ---------- */
const API = "https://api.tcgdex.net/v2/de";
const STORE_KEY  = "gradecheck_cards_v1";
const ARENA_KEY  = "gradecheck_arena_v1";
const META_KEY   = "gradecheck_meta_v1";
const TRADE_KEY  = "gradecheck_trades_v1";

const GRADE_NAMES = {
  10:"GEM MINT", 9:"MINT", 8:"NM-MINT", 7:"NEAR MINT", 6:"EX-MINT",
  5:"EXCELLENT", 4:"VG-EX", 3:"VERY GOOD", 2:"GOOD", 1:"POOR"
};

/* ====== PSA-ROI: Kosten & Wahrscheinlichkeitsmodell ======
   PSA-Gebühren: Stand 10.02.2026 (letzte offizielle Preiserhöhung).
   days = geschätzte Werktage laut PSA. Alle Werte in der App frei
   anpassbar – vor einer echten Einsendung aktuelle Preise prüfen
   (psacard.com). Value Bulk: min. 20 Karten + Club-Mitgliedschaft. */
const PSA_TIERS = [
  { id:"bulk",    name:"Value Bulk", usd:24.99, max:199,  days:95, note:"ab 20 Karten + Club-Mitgliedschaft ($149/Jahr)" },
  { id:"value",   name:"Value",      usd:30,    max:499,  days:75 },
  { id:"plus",    name:"Value Plus", usd:50,    max:999,  days:45 },
  { id:"regular", name:"Regular",    usd:80,    max:2499, days:25 },
  { id:"express", name:"Express",    usd:150,   max:4999, days:15 },
];
/* Zustandseinschätzung → Verteilung über Grades (Summe je Zeile = 1) */
const GRADE_PROFILES = {
  gem: { label:"Makellos",       hint:"scharfe Ecken, perfekt zentriert", p:{10:0.45, 9:0.40, 8:0.12, low:0.03} },
  nm:  { label:"Fast perfekt",   hint:"minimale Mängel bei genauem Blick", p:{10:0.20, 9:0.45, 8:0.25, low:0.10} },
  ex:  { label:"Leichte Mängel", hint:"sichtbares Whitening / leicht schief", p:{10:0.05, 9:0.30, 8:0.40, low:0.25} },
  pl:  { label:"Sichtbar bespielt", hint:"Kratzer, Knicke, Abrieb", p:{10:0.01, 9:0.12, 8:0.32, low:0.55} },
};

/* ---------- Speicher mit In-Memory-Fallback ---------- */
function storageAvailable(){
  try{ localStorage.setItem("__gc","1"); localStorage.removeItem("__gc"); return true; }
  catch(e){ return false; }
}
const HAS_LS = storageAvailable();
let memCards = null, memTrades = null;

function loadJSON(key, fallbackMem){
  if(HAS_LS){ try{ return JSON.parse(localStorage.getItem(key)) || []; }catch(e){ return []; } }
  return fallbackMem || [];
}
let collection = loadJSON(STORE_KEY);
let trades     = loadJSON(TRADE_KEY);

function persist(){
  if(HAS_LS){ try{ localStorage.setItem(STORE_KEY, JSON.stringify(collection)); return; }catch(e){ toast("Speicher voll – Export empfohlen"); } }
  memCards = collection;
}
function persistTrades(){
  if(HAS_LS){ try{ localStorage.setItem(TRADE_KEY, JSON.stringify(trades)); return; }catch(e){} }
  memTrades = trades;
}

let meta = (function(){
  if(HAS_LS){ try{ return Object.assign({lastExport:0}, JSON.parse(localStorage.getItem(META_KEY))||{}); }catch(e){} }
  return {lastExport:0};
})();
function persistMeta(){ if(HAS_LS){ try{ localStorage.setItem(META_KEY, JSON.stringify(meta)); }catch(e){} } }

const ARENA_DEFAULTS = {w:0, l:0, streak:0, best:0, diff:"normal"};
let arenaRecord = (function(){
  if(HAS_LS){ try{ return Object.assign({}, ARENA_DEFAULTS, JSON.parse(localStorage.getItem(ARENA_KEY))||{}); }catch(e){} }
  return Object.assign({}, ARENA_DEFAULTS);
})();
function persistArena(){ if(HAS_LS){ try{ localStorage.setItem(ARENA_KEY, JSON.stringify(arenaRecord)); }catch(e){} } }

/* ---------- Hilfen ---------- */
const $ = id => document.getElementById(id);
const eur = n => (Number(n)||0).toLocaleString("de-DE",{style:"currency",currency:"EUR"});
const round2 = n => Math.round(n*100)/100;
function esc(s){
  return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function toast(msg){
  const t = $("toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(t._h); t._h = setTimeout(()=>t.classList.remove("show"), 2200);
}
function buzz(p){ try{ if(navigator.vibrate) navigator.vibrate(p); }catch(e){} }
function imgURL(base, q){ return base ? `${base}/${q}.webp` : null; }
const clampNum = (v, min=0) => { const n = Number(v); return Number.isFinite(n) && n>=min ? n : 0; };

/* ---------- Ansichten ---------- */
const VIEWS = ["coll","scan","roi","trade","arena"];
function showView(v){
  VIEWS.forEach(name=>{
    const el = $("view"+name.charAt(0).toUpperCase()+name.slice(1));
    if(el) el.classList.toggle("hidden", name!==v);
    const tab = $("tab"+name.charAt(0).toUpperCase()+name.slice(1));
    if(tab) tab.setAttribute("aria-selected", String(name===v));
  });
  if(v==="scan")  setTimeout(()=>$("searchInput").focus(), 60);
  if(v==="roi")   renderRoi();
  if(v==="trade") renderTrade();
  if(v==="arena") renderArena();
}

/* ---------- Statistik ---------- */
function renderStats(){
  const totalQty = collection.reduce((s,c)=> s + (c.qty||1), 0);
  const totalVal = collection.reduce((s,c)=> s + (Number(c.value)||0)*(c.qty||1), 0);
  const graded = collection.filter(c=>c.grade);
  const avg = graded.length ? (graded.reduce((s,c)=>s+c.grade,0)/graded.length) : null;
  $("stCount").textContent = totalQty;
  $("stValue").textContent = eur(totalVal);
  $("stGrade").textContent = avg ? avg.toFixed(1) : "–";

  const buys = collection.filter(c=>c.buy!=null);
  const plEl = $("plRow");
  if(buys.length){
    const invested = buys.reduce((s,c)=> s + (Number(c.buy)||0)*(c.qty||1), 0);
    const pl = buys.reduce((s,c)=> s + ((Number(c.value)||0)-(Number(c.buy)||0))*(c.qty||1), 0);
    plEl.innerHTML = `<span>Investiert <b>${eur(invested)}</b></span>`+
      `<span>Bilanz <b class="${pl>=0?'ok':'bad'}">${pl>=0?'+':''}${eur(pl)}</b></span>`;
    plEl.classList.remove("hidden");
  } else plEl.classList.add("hidden");
}

/* ---------- ROI-Schnellbewertung pro Karte (für Sammlungs-Flag) ---------- */
function quickRoi(c){
  // Nur bewerten, wenn PSA-10-Wert vorhanden
  const v10 = clampNum(c.psa10), v9 = clampNum(c.psa9), raw = clampNum(c.value);
  if(v10<=0) return null;
  const cond = c.grade>=9 ? "gem" : c.grade>=7 ? "nm" : c.grade>=5 ? "ex" : "pl";
  const prof = GRADE_PROFILES[cond].p;
  const exp = prof[10]*v10 + prof[9]*(v9||v10*0.5) + prof[8]*(raw||0) + prof.low*raw;
  // Schnellschätzung: Value-Tier $30 + anteiliger Versand ~$35 (Stand 02/2026)
  const costEur = (30 + 35) * 0.92;
  const net = (exp - raw) - costEur;
  return net > 0;
}

/* ---------- Sammlung rendern ---------- */
function renderCollection(){
  renderStats();
  updateBackupNotice();
  const q = ($("filterInput").value||"").trim().toLowerCase();
  const sort = $("sortSelect").value;
  let list = collection.filter(c => !q || (c.name||"").toLowerCase().includes(q) || (c.set||"").toLowerCase().includes(q));
  const sorters = {
    new:(a,b)=>(b.added||0)-(a.added||0),
    valdesc:(a,b)=>(b.value||0)-(a.value||0),
    valasc:(a,b)=>(a.value||0)-(b.value||0),
    grade:(a,b)=>(b.grade||0)-(a.grade||0),
    name:(a,b)=>(a.name||"").localeCompare(b.name||"","de")
  };
  list.sort(sorters[sort] || sorters.new);

  const grid = $("grid"); grid.innerHTML = "";
  $("emptyColl").classList.toggle("hidden", collection.length>0);

  list.forEach(c=>{
    const img = c.photo || imgURL(c.apiImage,"low");
    const roi = quickRoi(c);
    const el = document.createElement("div");
    el.className = "slab";
    el.setAttribute("role","button");
    el.innerHTML = `
      <div class="band">
        <div class="nm">${esc(c.name)}<span class="set">${esc(c.set||"")}${c.number? " · "+esc(c.number):""}</span></div>
        <div class="grade">${c.grade}</div>
      </div>
      <div class="imgwrap">${img
        ? `<img loading="lazy" src="${esc(img)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'ph',textContent:'kein Bild'}))">`
        : `<div class="ph">kein Bild</div>`}</div>
      ${roi!==null ? `<div class="roi-flag ${roi?'':'no'}">${roi?'★ Grading lohnt':'Grading: nein'}</div>` : ``}
      <div class="foot"><span class="val">${eur(c.value)}</span><span class="qty">×${c.qty||1}</span></div>`;
    el.onclick = ()=>openDetail(c.id);
    grid.appendChild(el);
  });
}

/* ---------- TCGdex-Suche ---------- */
let searchTimer = null;
function onSearchInput(){
  clearTimeout(searchTimer);
  const q = $("searchInput").value.trim();
  if(q.length < 2){ $("results").innerHTML=""; $("searchSpin").classList.add("hidden"); return; }
  searchTimer = setTimeout(()=>runSearch(q), 380);
}
async function runSearch(q){
  $("searchSpin").classList.remove("hidden");
  $("apiNotice").classList.add("hidden");
  $("results").innerHTML = "";
  try{
    const res = await fetch(`${API}/cards?name=${encodeURIComponent(q)}`);
    if(!res.ok) throw new Error("HTTP "+res.status);
    const data = await res.json();
    $("searchSpin").classList.add("hidden");
    if(!Array.isArray(data) || data.length===0){
      $("results").innerHTML = `<div class="spin" style="grid-column:1/-1">Keine Treffer für „${esc(q)}“</div>`;
      return;
    }
    data.slice(0,36).forEach(card=>{
      const thumb = imgURL(card.image,"low");
      const el = document.createElement("button");
      el.className = "rcard";
      el.innerHTML = `
        <div class="imgwrap">${thumb
          ? `<img loading="lazy" src="${esc(thumb)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'ph',textContent:'kein Bild'}))">`
          : `<div class="ph">kein Bild</div>`}</div>
        <div class="nm">${esc(card.name)}</div>
        <div class="id">${esc(card.id)}</div>`;
      el.onclick = ()=>pickCard(card.id);
      $("results").appendChild(el);
    });
  }catch(err){
    $("searchSpin").classList.add("hidden");
    $("apiNotice").classList.remove("hidden");
  }
}
async function pickCard(cardId){
  toast("Lade Kartendaten …");
  let detail = null;
  try{ const res = await fetch(`${API}/cards/${encodeURIComponent(cardId)}`); if(res.ok) detail = await res.json(); }catch(e){}
  openForm({
    name: detail?.name || cardId,
    set: detail?.set?.name || "",
    number: detail?.localId ? `${detail.localId}${detail?.set?.cardCount?.official ? "/"+detail.set.cardCount.official : ""}` : "",
    rarity: detail?.rarity || "",
    apiId: cardId,
    apiImage: detail?.image || null
  });
}

/* ---------- Kamera (Capacitor nativ, sonst File-Input) ---------- */
async function openCamera(){
  if(Cap.native && Cap.Camera){
    try{
      const photo = await Cap.Camera.getPhoto({ quality:70, resultType:"dataUrl", source:"CAMERA" });
      openForm(null);
      photoData = photo.dataUrl;
      $("photoThumb").src = photoData;
      $("photoThumb").classList.remove("hidden");
      $("photoRemove").classList.remove("hidden");
      return;
    }catch(e){ /* abgebrochen → Fallback */ }
  }
  openForm(null);
  setTimeout(()=>$("fPhoto").click(), 120);
}

/* ---------- Formular ---------- */
let formDraft = null, editId = null, photoData = null;
function buildGradeChips(){
  const wrap = $("gradeChips"); wrap.innerHTML = "";
  for(let g=10; g>=1; g--){
    const b = document.createElement("button");
    b.className = "gchip"; b.textContent = g; b.setAttribute("aria-pressed","false");
    b.onclick = ()=>setGrade(g); wrap.appendChild(b);
  }
}
function setGrade(g){
  formDraft.grade = g;
  [...$("gradeChips").children].forEach(ch=>ch.setAttribute("aria-pressed", String(Number(ch.textContent)===g)));
  $("gradeName").textContent = `${g} · ${GRADE_NAMES[g]}`;
}
function openForm(cardData, existing){
  editId = existing ? existing.id : null;
  formDraft = existing ? {...existing}
    : { name:cardData?.name||"", set:cardData?.set||"", number:cardData?.number||"",
        rarity:cardData?.rarity||"", apiId:cardData?.apiId||null, apiImage:cardData?.apiImage||null, grade:8 };
  photoData = existing?.photo || null;

  $("formTitle").textContent = editId ? "Eintrag bearbeiten" : "Karte erfassen";
  $("formSub").textContent = formDraft.apiId ? `TCGdex · ${formDraft.apiId}` : "Manueller Eintrag";
  const manual = !formDraft.apiId;
  $("manualFields").style.display = manual ? "block" : "none";
  $("fName").value = formDraft.name || "";
  $("fSet").value  = formDraft.set || "";
  $("fNum").value  = formDraft.number || "";

  const thumb = photoData || imgURL(formDraft.apiImage,"low");
  $("formPreview").innerHTML = `
    <div class="imgwrap">${thumb
      ? `<img src="${esc(thumb)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'ph',textContent:'kein Bild'}))">`
      : `<div class="ph">kein Bild</div>`}</div>
    <div class="meta">
      <b>${esc(formDraft.name || "Neue Karte")}</b>
      <span>${esc(formDraft.set || "")}${formDraft.number? " · "+esc(formDraft.number):""}</span>
      ${formDraft.rarity? `<span>${esc(formDraft.rarity)}</span>`:""}
    </div>`;

  $("fQty").value = formDraft.qty || 1;
  $("fBuy").value = formDraft.buy ?? "";
  $("fVal").value = formDraft.value ?? "";
  $("fPsa9").value = formDraft.psa9 ?? "";
  $("fPsa10").value = formDraft.psa10 ?? "";
  $("fNote").value = formDraft.note || "";
  buildGradeChips(); setGrade(formDraft.grade || 8);

  $("photoThumb").classList.toggle("hidden", !photoData);
  $("photoRemove").classList.toggle("hidden", !photoData);
  if(photoData) $("photoThumb").src = photoData;

  $("formBack").classList.remove("hidden");
  document.body.style.overflow = "hidden";
}
function closeForm(){ $("formBack").classList.add("hidden"); document.body.style.overflow = ""; }

function onPhoto(ev){
  const file = ev.target.files && ev.target.files[0]; if(!file) return;
  const reader = new FileReader();
  reader.onload = e=>{
    const img = new Image();
    img.onload = ()=>{
      const MAX = 640, scale = Math.min(1, MAX/Math.max(img.width,img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.round(img.width*scale); cv.height = Math.round(img.height*scale);
      cv.getContext("2d").drawImage(img,0,0,cv.width,cv.height);
      photoData = cv.toDataURL("image/jpeg",0.72);
      $("photoThumb").src = photoData;
      $("photoThumb").classList.remove("hidden");
      $("photoRemove").classList.remove("hidden");
      toast("Foto hinzugefügt");
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file); ev.target.value = "";
}
function removePhoto(){ photoData = null; $("photoThumb").classList.add("hidden"); $("photoRemove").classList.add("hidden"); }

function saveCard(){
  if(!formDraft.apiId){
    formDraft.name = $("fName").value.trim();
    formDraft.set = $("fSet").value.trim();
    formDraft.number = $("fNum").value.trim();
  }
  if(!formDraft.name){ toast("Bitte Kartennamen angeben"); $("fName").focus(); return; }
  const entry = {
    id: editId || (Date.now().toString(36)+Math.random().toString(36).slice(2,7)),
    name: formDraft.name, set: formDraft.set || "", number: formDraft.number || "", rarity: formDraft.rarity || "",
    apiId: formDraft.apiId || null, apiImage: formDraft.apiImage || null, grade: formDraft.grade || 8,
    qty: Math.max(1, parseInt($("fQty").value,10)||1),
    buy: $("fBuy").value==="" ? null : Math.max(0, parseFloat($("fBuy").value)||0),
    value: $("fVal").value==="" ? 0 : Math.max(0, parseFloat($("fVal").value)||0),
    psa9: $("fPsa9").value==="" ? null : Math.max(0, parseFloat($("fPsa9").value)||0),
    psa10: $("fPsa10").value==="" ? null : Math.max(0, parseFloat($("fPsa10").value)||0),
    note: $("fNote").value.trim(), photo: photoData,
    added: editId ? (collection.find(c=>c.id===editId)?.added || Date.now()) : Date.now()
  };
  if(editId){ collection = collection.map(c=> c.id===editId ? entry : c); toast("Eintrag aktualisiert"); }
  else { collection.push(entry); toast("Im Tresor gespeichert"); }
  persist(); closeForm(); showView("coll"); renderCollection();
}

/* ---------- Detail ---------- */
function openDetail(id){
  const c = collection.find(x=>x.id===id); if(!c) return;
  const img = c.photo || imgURL(c.apiImage,"high") || imgURL(c.apiImage,"low");
  const totalVal = (Number(c.value)||0)*(c.qty||1);
  const pl = (c.buy!=null) ? (Number(c.value)||0) - Number(c.buy) : null;
  $("detailBody").innerHTML = `
    <h2 id="dTitle">${esc(c.name)}</h2>
    <div class="sub">${esc(c.set||"")}${c.number? " · "+esc(c.number):""}${c.apiId? " · "+esc(c.apiId):""}</div>
    ${img? `<img class="bigimg" src="${esc(img)}" alt="${esc(c.name)}" onerror="this.remove()">`:""}
    <div class="kv"><span class="k">Zustand (Selbsteinschätzung)</span><span class="v gold">${c.grade} · ${GRADE_NAMES[c.grade]||""}</span></div>
    <div class="kv"><span class="k">Menge</span><span class="v">×${c.qty||1}</span></div>
    <div class="kv"><span class="k">Wert pro Karte</span><span class="v gold">${eur(c.value)}</span></div>
    <div class="kv"><span class="k">Gesamtwert</span><span class="v gold">${eur(totalVal)}</span></div>
    ${c.buy!=null? `<div class="kv"><span class="k">Kaufpreis</span><span class="v">${eur(c.buy)}</span></div>`:""}
    ${pl!=null? `<div class="kv"><span class="k">Gewinn / Verlust pro Karte</span><span class="v ${pl>=0?"ok":"bad"}">${pl>=0?"+":""}${eur(pl)}</span></div>`:""}
    ${c.psa9!=null? `<div class="kv"><span class="k">PSA 9 Wert</span><span class="v">${eur(c.psa9)}</span></div>`:""}
    ${c.psa10!=null? `<div class="kv"><span class="k">PSA 10 Wert</span><span class="v">${eur(c.psa10)}</span></div>`:""}
    ${c.rarity? `<div class="kv"><span class="k">Seltenheit</span><span class="v">${esc(c.rarity)}</span></div>`:""}
    ${c.added? `<div class="kv"><span class="k">Erfasst am</span><span class="v">${new Date(c.added).toLocaleDateString("de-DE")}</span></div>`:""}
    ${c.note? `<div class="kv"><span class="k">Notiz</span><span class="v" style="font-family:var(--sans)">${esc(c.note)}</span></div>`:""}
    <div class="actions">
      <button class="btn danger" data-act="del">Löschen</button>
      <button class="btn ghost" data-act="roi">Grading prüfen</button>
      <button class="btn ghost" data-act="edit">Bearbeiten</button>
      <button class="btn" data-act="sell">Verkaufen</button>
    </div>`;
  $("detailBody").querySelector('[data-act="del"]').onclick = ()=>deleteCard(c.id);
  $("detailBody").querySelector('[data-act="roi"]').onclick = ()=>{ closeDetail(); showView("roi"); prefillRoi(c); };
  $("detailBody").querySelector('[data-act="edit"]').onclick = ()=>editCard(c.id);
  $("detailBody").querySelector('[data-act="sell"]').onclick = ()=>openListing(c.id);
  $("detailBack").classList.remove("hidden");
  document.body.style.overflow = "hidden";
}
function closeDetail(){ $("detailBack").classList.add("hidden"); document.body.style.overflow = ""; }
function editCard(id){ const c = collection.find(x=>x.id===id); if(!c) return; closeDetail(); openForm(null, c); }
function deleteCard(id){
  const c = collection.find(x=>x.id===id); if(!c) return;
  if(!confirm(`„${c.name}" wirklich aus dem Tresor löschen?`)) return;
  collection = collection.filter(x=>x.id!==id);
  persist(); closeDetail(); renderCollection(); toast("Gelöscht");
}

/* ============================================================
   GRADING-ROI-RECHNER
   ============================================================ */
let roiState = { condition:"nm", raw:0, psa9:0, psa10:0, tier:"value", shippingUsd:35, extraUsd:25, usdEur:0.92, cards:1, fromCard:null };

function evaluateRoi(s){
  const prof = (GRADE_PROFILES[s.condition]||GRADE_PROFILES.nm).p;
  const v10 = clampNum(s.psa10), v9 = clampNum(s.psa9), raw = clampNum(s.raw);
  const exp = prof[10]*v10 + prof[9]*v9 + prof[8]*raw*1.2 + prof.low*raw;
  const tier = PSA_TIERS.find(t=>t.id===s.tier) || PSA_TIERS[0];
  const usd = clampNum(tier.usd) + clampNum(s.shippingUsd) + clampNum(s.extraUsd);
  const rate = s.usdEur>0 ? s.usdEur : 0.92;
  const cost = usd * rate / Math.max(1, Math.floor(clampNum(s.cards)||1));
  const uplift = exp - raw;
  const net = uplift - cost;
  const pGem = prof[10], p9plus = prof[10]+prof[9];
  let breakEven = null;
  if(prof[10] > 0){
    const rest = prof[9]*v9 + prof[8]*raw*1.2 + prof.low*raw;
    breakEven = (raw + cost - rest) / prof[10];
    if(breakEven < 0) breakEven = 0;
  }
  let verdict = net > cost*0.5 ? "go" : net > 0 ? "maybe" : "no";
  return { exp:round2(exp), cost:round2(cost), uplift:round2(uplift), net:round2(net),
           pGem, p9plus, breakEven: breakEven==null?null:round2(breakEven), verdict, tierName:tier.name, days:tier.days };
}

function prefillRoi(c){
  roiState.fromCard = c.id;
  roiState.raw = Number(c.value)||0;
  roiState.psa9 = Number(c.psa9)||0;
  roiState.psa10 = Number(c.psa10)||0;
  roiState.condition = c.grade>=9 ? "gem" : c.grade>=7 ? "nm" : c.grade>=5 ? "ex" : "pl";
  renderRoi();
}

function renderRoi(){
  const r = evaluateRoi(roiState);
  const condChips = Object.entries(GRADE_PROFILES).map(([k,v])=>`
    <button class="cond-chip" aria-pressed="${roiState.condition===k}" data-cond="${k}">
      ${v.label}<small>${Math.round(v.p[10]*100)}% PSA 10</small>
    </button>`).join("");
  const tierOpts = PSA_TIERS.map(t=>`<option value="${t.id}" ${roiState.tier===t.id?"selected":""}>${t.name} – $${t.usd} · ~${t.days} Tage · bis $${t.max}</option>`).join("");

  const verdictText = { go:"GRADING LOHNT SICH", maybe:"GRENZWERTIG", no:"GRADING LOHNT NICHT" }[r.verdict];
  const verdictSub = {
    go:`Erwarteter Netto-Gewinn nach allen Kosten`,
    maybe:`Knapp positiv – Wertschätzung genau prüfen`,
    no:`Kosten übersteigen den erwarteten Wertzuwachs`
  }[r.verdict];

  $("roiRoot").innerHTML = `
    <div class="hint">Berechnet, ob sich das Einschicken zu PSA lohnt – aus deiner Zustands­einschätzung, dem Rohwert und den PSA-Werten. Alle Kosten sind anpassbar.</div>

    ${roiState.fromCard ? `<div class="notice gold">Werte aus „${esc((collection.find(c=>c.id===roiState.fromCard)||{}).name||"Karte")}" übernommen.</div>` : ``}

    <div class="field">
      <label>Zustandseinschätzung</label>
      <div class="cond-chips" id="condChips">${condChips}</div>
      <div class="gname">${GRADE_PROFILES[roiState.condition].label} – ${GRADE_PROFILES[roiState.condition].hint}</div>
    </div>

    <div class="row2">
      <div class="field"><label>Rohwert (€)</label><input id="roiRaw" type="number" min="0" step="0.01" inputmode="decimal" value="${roiState.raw||""}"></div>
      <div class="field"><label>PSA 9 Wert (€)</label><input id="roiPsa9" type="number" min="0" step="0.01" inputmode="decimal" value="${roiState.psa9||""}"></div>
    </div>
    <div class="field"><label>PSA 10 Wert (€)</label><input id="roiPsa10" type="number" min="0" step="0.01" inputmode="decimal" value="${roiState.psa10||""}"></div>

    <div class="field"><label>PSA Service-Level</label><select id="roiTier">${tierOpts}</select></div>
    <div class="row2">
      <div class="field"><label>Versand gesamt ($)</label><input id="roiShip" type="number" min="0" step="1" inputmode="decimal" value="${roiState.shippingUsd}"></div>
      <div class="field"><label>Zoll/EUSt pauschal ($)</label><input id="roiExtra" type="number" min="0" step="1" inputmode="decimal" value="${roiState.extraUsd}"></div>
    </div>
    <div class="row2">
      <div class="field"><label>Karten je Sendung</label><input id="roiCards" type="number" min="1" step="1" inputmode="numeric" value="${roiState.cards}"></div>
      <div class="field"><label>USD→EUR Kurs</label><input id="roiRate" type="number" min="0" step="0.01" inputmode="decimal" value="${roiState.usdEur}"></div>
    </div>

    <div class="verdict ${r.verdict}">
      ${verdictText}
      <span class="sub">${verdictSub}</span>
    </div>

    <div class="roi-calc">
      <div class="roi-title">Berechnung pro Karte</div>
      <div class="roi-row"><span class="roi-label">Chance auf PSA 10</span><span class="roi-value">${Math.round(r.pGem*100)} %</span></div>
      <div class="roi-row"><span class="roi-label">Chance auf PSA 9+</span><span class="roi-value">${Math.round(r.p9plus*100)} %</span></div>
      <div class="roi-row"><span class="roi-label">Erwarteter Wert nach Grading</span><span class="roi-value">${eur(r.exp)}</span></div>
      <div class="roi-row"><span class="roi-label">– Rohwert heute</span><span class="roi-value">${eur(roiState.raw)}</span></div>
      <div class="roi-row"><span class="roi-label">= Erwarteter Wertzuwachs</span><span class="roi-value ${r.uplift>=0?'roi-positive':'roi-negative'}">${r.uplift>=0?'+':''}${eur(r.uplift)}</span></div>
      <div class="roi-row"><span class="roi-label">– Kosten (${r.tierName} + Versand)</span><span class="roi-value">${eur(r.cost)}</span></div>
      <div class="roi-row"><span class="roi-label">= Netto-Gewinn erwartet</span><span class="roi-value ${r.net>=0?'roi-positive':'roi-negative'}">${r.net>=0?'+':''}${eur(r.net)}</span></div>
      ${r.breakEven!=null ? `<div class="roi-row"><span class="roi-label">Lohnt ab PSA-10-Wert von</span><span class="roi-value">${eur(r.breakEven)}</span></div>`:""}
    </div>

    <div class="notice">Hinweis: Die Wahrscheinlichkeiten sind konservative Richtwerte, keine Garantie. Die echte PSA-Note hängt von Zentrierung, Ecken, Kanten und Oberfläche ab.</div>
  `;

  // Events anbinden
  $("condChips").querySelectorAll("[data-cond]").forEach(b=> b.onclick = ()=>{ roiState.condition = b.getAttribute("data-cond"); renderRoi(); });
  const bind = (id, key, int)=>{ const el=$(id); if(el) el.oninput = ()=>{ roiState[key] = int ? (parseInt(el.value,10)||0) : (parseFloat(el.value)||0); liveRoi(); }; };
  bind("roiRaw","raw"); bind("roiPsa9","psa9"); bind("roiPsa10","psa10");
  bind("roiShip","shippingUsd"); bind("roiExtra","extraUsd"); bind("roiCards","cards",true); bind("roiRate","usdEur");
  $("roiTier").onchange = ()=>{ roiState.tier = $("roiTier").value; renderRoi(); };
}
// Nur die Ergebnis-Boxen aktualisieren, ohne Eingabefelder neu zu rendern (kein Fokusverlust)
function liveRoi(){
  const r = evaluateRoi(roiState);
  const root = $("roiRoot");
  const v = root.querySelector(".verdict");
  if(v){
    v.className = "verdict "+r.verdict;
    v.innerHTML = `${{go:"GRADING LOHNT SICH",maybe:"GRENZWERTIG",no:"GRADING LOHNT NICHT"}[r.verdict]}<span class="sub">${{go:"Erwarteter Netto-Gewinn nach allen Kosten",maybe:"Knapp positiv – Wertschätzung genau prüfen",no:"Kosten übersteigen den erwarteten Wertzuwachs"}[r.verdict]}</span>`;
  }
  const rows = root.querySelectorAll(".roi-calc .roi-row .roi-value");
  if(rows.length>=7){
    rows[0].textContent = Math.round(r.pGem*100)+" %";
    rows[1].textContent = Math.round(r.p9plus*100)+" %";
    rows[2].textContent = eur(r.exp);
    rows[3].textContent = eur(roiState.raw);
    rows[4].textContent = (r.uplift>=0?'+':'')+eur(r.uplift); rows[4].className = "roi-value "+(r.uplift>=0?'roi-positive':'roi-negative');
    rows[5].textContent = eur(r.cost);
    rows[6].textContent = (r.net>=0?'+':'')+eur(r.net); rows[6].className = "roi-value "+(r.net>=0?'roi-positive':'roi-negative');
    if(rows[7] && r.breakEven!=null) rows[7].textContent = eur(r.breakEven);
  }
}

/* ============================================================
   LISTING-GENERATOR
   ============================================================ */
let listingCard = null, listingMode = "long";
function buildListing(c, mode){
  const gradeTxt = `${c.grade}/10 – ${GRADE_NAMES[c.grade]||""}`;
  if(mode==="short"){
    let t = `Zustand ${gradeTxt} (ehrliche Selbsteinschätzung, kein offizielles Grading).`;
    if(c.note) t += ` ${c.note}.`;
    t += " Versand sicher in Hülle & Toploader.";
    return { title:"", body:t };
  }
  const title = ([c.name, c.set, c.number].filter(Boolean).join(" · ") + ` – Zustand ${c.grade}/10`);
  const idLine = [c.set, c.number? "Nr. "+c.number : "", c.rarity].filter(Boolean).join(" · ");
  const lines = [
    c.name, idLine || null, "",
    `ZUSTAND (Selbsteinschätzung): ${gradeTxt}`,
    c.note? `Details: ${c.note}` : null,
    "Hinweis: Die Zustandsangabe ist meine ehrliche Selbsteinschätzung nach PSA-Skala, kein offizielles Grading. Die Fotos zeigen die tatsächlich angebotene Karte.",
    "",
    `Preis: ${eur(c.value)}${(c.qty||1)>1? ` pro Karte (${c.qty} verfügbar)` : ""}`,
    "Versand: sicher verpackt in Schutzhülle und Toploader.",
    "", "Privatverkauf – keine Garantie, Gewährleistung oder Rücknahme."
  ].filter(l=>l!==null);
  return { title, body: lines.join("\n") };
}
function openListing(id){
  const c = collection.find(x=>x.id===id); if(!c) return;
  listingCard = c; listingMode = "long";
  $("lSub").textContent = `${c.name}${c.set? " · "+c.set : ""}`;
  applyListing(); closeDetail();
  $("listingBack").classList.remove("hidden"); document.body.style.overflow = "hidden";
}
function applyListing(){
  const l = buildListing(listingCard, listingMode);
  $("lmLong").setAttribute("aria-pressed", String(listingMode==="long"));
  $("lmShort").setAttribute("aria-pressed", String(listingMode==="short"));
  $("lTitleField").style.display = listingMode==="long" ? "block" : "none";
  $("lTitleInput").value = l.title; $("lBody").value = l.body; updateCharCount();
}
function setListingMode(m){ listingMode = m; applyListing(); }
function updateCharCount(){
  const n = $("lTitleInput").value.length, el = $("lCharCount");
  el.textContent = `${n}/80 Zeichen (eBay-Titel-Limit)`;
  el.classList.toggle("over", n>80);
}
function listingFullText(){
  const t = $("lTitleInput").value.trim(), b = $("lBody").value;
  return (listingMode==="long" && t) ? t+"\n\n"+b : b;
}
async function copyListing(){
  const text = listingFullText();
  try{ await navigator.clipboard.writeText(text); toast("In Zwischenablage kopiert"); }
  catch(e){ const ta=$("lBody"); ta.focus(); ta.select(); try{ document.execCommand("copy"); toast("Kopiert"); }catch(e2){ toast("Bitte Text manuell markieren"); } }
}
async function shareListing(){
  const text = listingFullText();
  if(navigator.share){ try{ await navigator.share({ text }); }catch(e){} } else copyListing();
}
function closeListing(){ $("listingBack").classList.add("hidden"); document.body.style.overflow = ""; }

/* ============================================================
   HANDEL
   ============================================================ */
let tradeKind = "sell";
const TRADE_BADGE = { sell:["badge-sell","Biete"], want:["badge-want","Suche"], trade:["badge-trade","Tausch"] };
function renderTrade(){
  const root = $("tradeRoot");
  let html = `
    <button class="btn block" onclick="openTradeForm()" style="margin-bottom:14px">＋ Neues Angebot</button>`;
  if(trades.length===0){
    html += `<div class="empty"><b>Noch keine Angebote</b>Erstelle dein erstes Biete-, Such- oder Tauschangebot.</div>`;
  } else {
    trades.slice().reverse().forEach(t=>{
      const [cls,label] = TRADE_BADGE[t.kind] || TRADE_BADGE.sell;
      html += `
        <div class="trade-item">
          <div class="trade-head">
            <span class="trade-badge ${cls}">${label}</span>
            <button class="btn danger" style="padding:5px 10px;font-size:12px" data-del="${t.id}">✕</button>
          </div>
          <div class="nm">${esc(t.name)}</div>
          <div class="meta">${t.cond? "Zustand "+esc(String(t.cond))+"/10":""}${t.contact? " · "+esc(t.contact):""}</div>
          ${t.note? `<div class="meta">${esc(t.note)}</div>`:""}
          ${t.price? `<div class="price" style="margin-top:6px">${eur(t.price)}</div>`:""}
        </div>`;
    });
  }
  root.innerHTML = html;
  root.querySelectorAll("[data-del]").forEach(b=> b.onclick = ()=>{
    const id = b.getAttribute("data-del");
    trades = trades.filter(x=>x.id!==id); persistTrades(); renderTrade(); toast("Angebot gelöscht");
  });
}
function setTradeKind(k){
  tradeKind = k;
  ["sell","want","trade"].forEach(x=> $("tm"+x.charAt(0).toUpperCase()+x.slice(1)).setAttribute("aria-pressed", String(x===k)));
}
function openTradeForm(){
  tradeKind = "sell"; setTradeKind("sell");
  $("tfName").value = ""; $("tfCond").value = ""; $("tfPrice").value = ""; $("tfContact").value = ""; $("tfNote").value = "";
  $("tradeFormBack").classList.remove("hidden"); document.body.style.overflow = "hidden";
}
function closeTradeForm(){ $("tradeFormBack").classList.add("hidden"); document.body.style.overflow = ""; }
function saveTrade(){
  const name = $("tfName").value.trim();
  if(!name){ toast("Bitte Karte angeben"); $("tfName").focus(); return; }
  trades.push({
    id: Date.now().toString(36)+Math.random().toString(36).slice(2,7),
    kind: tradeKind, name,
    cond: $("tfCond").value==="" ? null : Math.max(1,Math.min(10,parseInt($("tfCond").value,10)||0)),
    price: $("tfPrice").value==="" ? null : Math.max(0,parseFloat($("tfPrice").value)||0),
    contact: $("tfContact").value.trim(), note: $("tfNote").value.trim(), added: Date.now()
  });
  persistTrades(); closeTradeForm(); renderTrade(); toast("Angebot gespeichert");
}

/* ============================================================
   EXPORT / IMPORT
   ============================================================ */
function updateBackupNotice(){
  const due = collection.length>=10 && (Date.now()-(meta.lastExport||0)) > 7*24*3600*1000;
  $("backupNotice").classList.toggle("hidden", !due);
}
function openExport(){
  if(collection.length===0){ toast("Tresor ist leer"); return; }
  $("exportBack").classList.remove("hidden"); document.body.style.overflow = "hidden";
}
function closeExport(){ $("exportBack").classList.add("hidden"); document.body.style.overflow = ""; }
function downloadFile(content, name, type){
  const blob = new Blob(content, {type});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href), 4000);
}
function csvField(v){ return '"'+String(v??"").replace(/"/g,'""')+'"'; }
function csvNum(n){ return (n==null||n==="") ? "" : String(Number(n)).replace(".", ","); }
function exportCSV(){
  if(collection.length===0){ toast("Tresor ist leer"); return; }
  const head = ["Name","Set","Nummer","Seltenheit","Zustand (1-10)","Menge","Kaufpreis EUR","Wert EUR","PSA9 EUR","PSA10 EUR","Gesamtwert EUR","Notiz"];
  const rows = collection.map(c=>[
    csvField(c.name), csvField(c.set), csvField(c.number), csvField(c.rarity),
    c.grade, c.qty||1, csvNum(c.buy), csvNum(c.value), csvNum(c.psa9), csvNum(c.psa10),
    csvNum((Number(c.value)||0)*(c.qty||1)), csvField(c.note)
  ].join(";"));
  const csv = "\uFEFF"+head.join(";")+"\r\n"+rows.join("\r\n");
  downloadFile([csv], `gradecheck-${new Date().toISOString().slice(0,10)}.csv`, "text/csv;charset=utf-8");
  meta.lastExport = Date.now(); persistMeta(); updateBackupNotice(); closeExport(); toast("CSV-Export erstellt");
}
function exportJSON(){
  if(collection.length===0){ toast("Tresor ist leer"); return; }
  downloadFile(
    [JSON.stringify({app:"GradeCheckVault", version:1, exported:new Date().toISOString(), cards:collection, trades}, null, 2)],
    `gradecheck-backup-${new Date().toISOString().slice(0,10)}.json`, "application/json");
  meta.lastExport = Date.now(); persistMeta(); updateBackupNotice(); closeExport(); toast("Backup erstellt");
}
function importJSON(ev){
  const file = ev.target.files && ev.target.files[0]; if(!file) return;
  const reader = new FileReader();
  reader.onload = e=>{
    try{
      const data = JSON.parse(e.target.result);
      const cards = Array.isArray(data) ? data : data.cards;
      if(!Array.isArray(cards)) throw new Error("Format");
      const valid = cards.filter(c=> c && c.name);
      if(valid.length===0) throw new Error("leer");
      if(!confirm(`${valid.length} Karten gefunden. Zum Tresor hinzufügen?`)) return;
      const existing = new Set(collection.map(c=>c.id));
      valid.forEach(c=>{
        if(!c.id || existing.has(c.id)) c.id = Date.now().toString(36)+Math.random().toString(36).slice(2,7);
        if(!c.grade) c.grade = 8;
        collection.push(c);
      });
      if(Array.isArray(data.trades)){ data.trades.forEach(t=>{ if(t&&t.name){ t.id = t.id||Date.now().toString(36)+Math.random().toString(36).slice(2,7); trades.push(t); } }); persistTrades(); }
      persist(); renderCollection(); toast(`${valid.length} Karten importiert`);
    }catch(err){ toast("Import fehlgeschlagen – Datei prüfen"); }
  };
  reader.readAsText(file); ev.target.value = "";
}

/* ============================================================
   ARENA — Sammlung als Deck (eigene Spielmechanik)
   ============================================================ */
const DIFF_MULT  = { leicht:0.94, normal:1, schwer:1.07 };
const DIFF_LABEL = { leicht:"LEICHT", normal:"NORMAL", schwer:"SCHWER" };
const TIER_FX = {
  0:{name:"–"}, 1:{name:"KRIT 20%"}, 2:{name:"GLANZSCHILD"}, 3:{name:"KRIT 30%"}, 4:{name:"LEBENSRAUB"}
};
function rarityTier(c){
  const r = (c.rarity||"").toLowerCase();
  if(/secret|gold|rainbow|hyper/.test(r)) return 4;
  if(/ultra|illustration|promo|spezial/.test(r)) return 3;
  if(/holo/.test(r)) return 2;
  if(/selten|rare|ungew/.test(r)) return 1;
  const v = Number(c.value)||0;
  if(v >= 100) return 3; if(v >= 25) return 2; if(v >= 5) return 1; return 0;
}
function toFighter(c){
  const atk = 10 + Math.round(14 * Math.log10(1 + (Number(c.value)||0)));
  const hp  = 30 + (c.grade||5) * 9;
  return { name:c.name, set:c.set||"", img: c.photo || imgURL(c.apiImage,"low"), atk, hp, maxHp:hp, tier:rarityTier(c), ko:false };
}
const NPC_POOL = [
  {name:"Knickfalte"},{name:"Wasserschaden"},{name:"Sonnenbleiche"},{name:"Eselsohr"},{name:"Klebe-Rest"},
  {name:"Kratzer-Schwarm"},{name:"Schimmelfleck"},{name:"Preisaufkleber"},{name:"Grobe Hülle"},{name:"Fälschung"}
];
function makeEnemies(team){
  const n = team.length;
  const avgAtk = team.reduce((s,f)=>s+f.atk,0)/n;
  const avgHp  = team.reduce((s,f)=>s+f.maxHp,0)/n;
  const base = [0, 1.13, 1.08, 1.07][n] || 1.08;
  const bias = base * (DIFF_MULT[arenaRecord.diff] || 1);
  const pool = [...NPC_POOL].sort(()=>Math.random()-0.5).slice(0,n);
  return pool.map(p=>{
    const atk = Math.max(6, Math.round(avgAtk*(bias-0.2+Math.random()*0.4)));
    const hp  = Math.max(30, Math.round(avgHp*(bias-0.2+Math.random()*0.4)/10)*10);
    const tier = Math.random()<0.25 ? 1 : (Math.random()<0.12 ? 2 : 0);
    return {name:p.name, set:"Gefahren-Deck", img:null, atk, hp, maxHp:hp, tier, ko:false};
  });
}
let deckSel = new Set(), battle = null;
function setDiff(d){ if(!DIFF_MULT[d]) return; arenaRecord.diff = d; persistArena(); renderSetup(); }
function renderArena(){
  if(battle && !battle.over) return renderFight();
  if(battle &&  battle.over) return renderEnd();
  renderSetup();
}
function renderSetup(){
  const root = $("arenaRoot");
  deckSel = new Set([...deckSel].filter(id=>collection.some(c=>c.id===id)));
  if(collection.length===0){
    root.innerHTML = `<div class="empty"><b>Kein Deck ohne Karten</b>Erfasse zuerst Karten im Tresor – dann treten sie hier an.<button class="btn" onclick="showView('scan')">Karte scannen</button></div>`;
    return;
  }
  let html = `
    <div class="arena-head">
      <div class="arena-rule">WERT → STÄRKE · ZUSTAND → AUSDAUER · SELTENHEIT → SPEZIAL</div>
      <div class="arena-rec">Bilanz: <b>${arenaRecord.w}</b> S · <b>${arenaRecord.l}</b> N</div>
    </div>
    <div class="arena-head"><span class="streak">Serie: ${arenaRecord.streak} · Rekord: ${arenaRecord.best}</span></div>
    <div class="diffchips">
      <button aria-pressed="${arenaRecord.diff==='leicht'}" data-diff="leicht">LEICHT</button>
      <button aria-pressed="${arenaRecord.diff==='normal'}" data-diff="normal">NORMAL</button>
      <button aria-pressed="${arenaRecord.diff==='schwer'}" data-diff="schwer">SCHWER</button>
    </div>
    <div class="hint">Wähle bis zu 3 Karten für dein Kampf-Deck. Dein Gegner: das Gefahren-Deck – alles, was Sammler fürchten.</div>
    <div class="deckgrid">`;
  collection.forEach(c=>{
    const f = toFighter(c), sel = deckSel.has(c.id);
    html += `
      <button class="dcard ${sel?'sel':''}" data-pick="${c.id}" aria-pressed="${sel}">
        <div class="band"><div class="nm">${esc(c.name)}</div><div class="grade">${c.grade}</div></div>
        <div class="dstats"><span>STÄRKE <b>${f.atk}</b></span><span>AUSDAUER <b>${f.maxHp}</b></span></div>
        <div class="fx t${f.tier}">${TIER_FX[f.tier].name}</div>
      </button>`;
  });
  html += `</div>
    <button class="btn block" id="startBattleBtn" style="margin-top:16px" ${deckSel.size? "":"disabled"}>Kampf starten (${deckSel.size}/3)</button>`;
  root.innerHTML = html;
  root.querySelectorAll("[data-diff]").forEach(b=> b.onclick = ()=>setDiff(b.getAttribute("data-diff")));
  root.querySelectorAll("[data-pick]").forEach(b=> b.onclick = ()=>toggleDeck(b.getAttribute("data-pick")));
  const sb = $("startBattleBtn"); if(sb) sb.onclick = startBattle;
}
function toggleDeck(id){
  if(deckSel.has(id)) deckSel.delete(id);
  else { if(deckSel.size>=3){ toast("Maximal 3 Karten im Deck"); return; } deckSel.add(id); }
  renderSetup();
}
function startBattle(){
  const team = collection.filter(c=>deckSel.has(c.id)).map(toFighter);
  if(team.length===0){ battle=null; toast("Deck ist leer"); renderSetup(); return; }
  battle = { p:team, e:makeEnemies(team), pa:0, ea:0, shield:true, shieldUp:false, switching:false,
             log:["Das Gefahren-Deck fordert dich heraus!"], over:false, won:false, busy:false, hitE:false, hitP:false };
  renderFight();
}
function bLog(m){ battle.log.push(m); }
function alive(team){ return team.filter(f=>!f.ko).length; }
function hpClass(f){ const r=f.hp/f.maxHp; return r>0.5? "" : (r>0.25? "mid":"low"); }
function fighterPanel(f, side, hit){
  return `
   <div class="fighter ${side}${hit?' hit':''}">
     <div class="band">
       <div><div class="nm">${esc(f.name)}</div><span class="set">${esc(f.set)}</span></div>
       <div class="fx t${f.tier}" style="margin:0">${TIER_FX[f.tier].name}</div>
     </div>
     <div class="frow">
       ${f.img? `<img class="fimg" src="${esc(f.img)}" alt="" onerror="this.remove()">`:""}
       <div class="fdata">
         <div class="hpnum">${f.hp} / ${f.maxHp}</div>
         <div class="hpbar"><i class="${hpClass(f)}" style="width:${Math.max(0,100*f.hp/f.maxHp)}%"></i></div>
         <div class="statline">STÄRKE ${f.atk}</div>
       </div>
     </div>
   </div>`;
}
function benchHTML(){
  const items = battle.p.map((f,i)=> i===battle.pa ? "" :
    `<button class="bchip ${f.ko?'ko':''}" ${f.ko||battle.busy?'disabled':''} data-switch="${i}">${esc(f.name)} · ${f.ko?'✕':f.hp+' AUS'}</button>`).join("");
  return items? `<div class="benchrow">${items}</div>`:"";
}
function renderFight(){
  const b = battle;
  const hitE = b.hitE, hitP = b.hitP; b.hitE = b.hitP = false;
  const logHtml = b.log.slice(-6).map(l=>`<div>› ${esc(l)}</div>`).join("");
  $("arenaRoot").innerHTML = `
    ${fighterPanel(b.e[b.ea],"enemy",hitE)}
    <div class="blog" id="blog">${logHtml}</div>
    ${fighterPanel(b.p[b.pa],"me",hitP)}
    ${b.switching? benchHTML():""}
    <div class="abtns">
      <button class="btn" id="atkBtn" ${b.busy?'disabled':''}>Angriff</button>
      <button class="btn ghost" id="swBtn" ${b.busy||alive(b.p)<2?'disabled':''}>Wechseln</button>
      <button class="btn ghost" id="shBtn" ${b.busy||!b.shield?'disabled':''}>Hülle ${b.shield?'(1×)':'✓'}</button>
    </div>
    <button class="btn danger block" id="fleeBtn" style="margin-top:12px" ${b.busy?'disabled':''}>Aufgeben</button>`;
  const lg = $("blog"); if(lg) lg.scrollTop = lg.scrollHeight;
  const on = (id,fn)=>{ const el=$(id); if(el) el.onclick=fn; };
  on("atkBtn", doAttack); on("swBtn", toggleSwitch); on("shBtn", doShield); on("fleeBtn", fleeBattle);
  $("arenaRoot").querySelectorAll("[data-switch]").forEach(b2=> b2.onclick = ()=>doSwitch(parseInt(b2.getAttribute("data-switch"),10)));
}
function calcHit(att, def){
  let d = att.atk * (0.85 + Math.random()*0.3);
  const cc = att.tier===1 ? 0.2 : (att.tier===3 ? 0.3 : 0);
  if(Math.random() < cc) d *= 2;
  if(def.tier===2) d *= 0.8;
  return { d: Math.max(1, Math.round(d)), crit: false };
}
function playerStrike(){
  const b = battle, me = b.p[b.pa], en = b.e[b.ea];
  const hit = calcHit(me, en);
  en.hp = Math.max(0, en.hp - hit.d); b.hitE = true; buzz(12);
  bLog(`${me.name} trifft ${en.name}: −${hit.d}`);
  if(me.tier===4 && hit.d>0){ const h = Math.round(hit.d*0.3); me.hp = Math.min(me.maxHp, me.hp+h); bLog(`${me.name} heilt +${h} (Lebensraub)`); }
  if(en.hp<=0){
    en.ko = true; bLog(`${en.name} ist erledigt!`);
    const next = b.e.findIndex(f=>!f.ko);
    if(next<0){ endBattle(true); return false; }
    b.ea = next; bLog(`Das Gefahren-Deck schickt ${b.e[next].name} – Konter folgt!`);
  }
  return true;
}
function doAttack(){ const b=battle; if(!b||b.busy||b.over) return; b.switching=false; b.busy=true; if(!playerStrike()) return; renderFight(); setTimeout(enemyTurn, 650); }
function toggleSwitch(){ battle.switching = !battle.switching; renderFight(); }
function doSwitch(i){ const b=battle; if(!b||b.busy||b.over||b.p[i].ko||i===b.pa) return; b.switching=false; b.busy=true; b.pa=i; bLog(`${b.p[i].name} springt ein und greift sofort an!`); if(!playerStrike()) return; renderFight(); setTimeout(enemyTurn, 650); }
function doShield(){ const b=battle; if(!b||b.busy||b.over||!b.shield) return; b.switching=false; b.busy=true; b.shield=false; b.shieldUp=true; bLog("Du legst die Schutzhülle an – der nächste Treffer prallt ab."); renderFight(); setTimeout(enemyTurn, 650); }
function enemyTurn(){
  const b = battle; if(!b||b.over) return;
  const en = b.e[b.ea], me = b.p[b.pa];
  if(b.shieldUp){
    b.shieldUp = false;
    const reflect = Math.max(1, Math.round(en.atk*0.5));
    en.hp = Math.max(0, en.hp - reflect); b.hitE = true; buzz(12);
    bLog(`${en.name} greift an – prallt an der Hülle ab! Konter: −${reflect}`);
    if(en.hp<=0){ en.ko = true; bLog(`${en.name} ist erledigt!`); const next = b.e.findIndex(f=>!f.ko); if(next<0) return endBattle(true); b.ea = next; bLog(`Das Gefahren-Deck schickt ${b.e[next].name}!`); }
  } else {
    const hit = calcHit(en, me);
    me.hp = Math.max(0, me.hp - hit.d); b.hitP = true; buzz(18);
    bLog(`${en.name} greift an: −${hit.d}`);
    if(me.hp<=0){
      me.ko = true; bLog(`${me.name} ist kampfunfähig!`);
      const next = b.p.findIndex(f=>!f.ko);
      if(next<0) return endBattle(false);
      b.pa = next; bLog(`${b.p[next].name} springt ein!`);
    }
  }
  b.busy = false; renderFight();
}
function endBattle(won){
  battle.over = true; battle.won = won; battle.busy = false;
  if(won){ arenaRecord.w++; arenaRecord.streak++; if(arenaRecord.streak>arenaRecord.best) arenaRecord.best=arenaRecord.streak; buzz([30,60,30]); }
  else { arenaRecord.l++; arenaRecord.streak = 0; buzz(80); }
  persistArena(); renderEnd();
}
function renderEnd(){
  const b = battle;
  $("arenaRoot").innerHTML = `
    <div class="endpanel ${b.won?'win':'lose'}">
      <div class="endword">${b.won? 'SIEG':'NIEDERLAGE'}</div>
      <p>${b.won? 'Deine Sammlung hat das Gefahren-Deck abgewehrt.':'Das Gefahren-Deck war diesmal stärker – Revanche?'}</p>
      <div class="arena-rec">Bilanz: <b>${arenaRecord.w}</b> Siege · <b>${arenaRecord.l}</b> Niederlagen · ${DIFF_LABEL[arenaRecord.diff]||""}</div>
      <div class="streak" style="margin-top:6px">Serie: ${arenaRecord.streak} · Rekord: ${arenaRecord.best}</div>
      <div class="actions">
        <button class="btn ghost" id="againDeck">Deck ändern</button>
        <button class="btn" id="againFight">Nochmal kämpfen</button>
      </div>
    </div>`;
  $("againDeck").onclick = ()=>{ battle=null; renderArena(); };
  $("againFight").onclick = startBattle;
}
function fleeBattle(){ if(!battle||battle.over) return; if(!confirm("Kampf wirklich aufgeben? Zählt als Niederlage.")) return; endBattle(false); }

/* ============================================================
   START
   ============================================================ */
// Globale Handler für inline-onclick im HTML
Object.assign(window, {
  showView, renderCollection, onSearchInput, runSearch, openForm, closeForm, saveCard,
  onPhoto, removePhoto, openCamera, openExport, closeExport, exportJSON, exportCSV, importJSON,
  setListingMode, copyListing, shareListing, closeListing, updateCharCount,
  openTradeForm, closeTradeForm, saveTrade, setTradeKind, closeDetail
});

(async function start(){
  await initCapacitor();
  if(!HAS_LS) $("storageNotice").classList.remove("hidden");
  renderCollection();
})();
