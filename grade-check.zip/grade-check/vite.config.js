import { defineConfig } from "vite";

// base: "./" → relative Pfade, damit die App auch in einem Unterordner
// (GitHub Pages: /repo-name/) oder auf Neocities ohne Anpassung läuft.
export default defineConfig({
  base: "./",
  build: {
    target: "es2018",
    outDir: "dist",
    assetsDir: "assets",
    sourcemap: false
  },
  server: {
    port: 5173,
    host: true
  }
});
