/* Grade-Check Vault — Service Worker
   App-Shell-Caching für Offline-Betrieb. Netzwerk-zuerst für die
   TCGdex-API (immer frische Daten), Cache-zuerst für die App-Shell. */
const CACHE = "gradecheck-v1";
const SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./icons/icon.svg",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", e=>{
  e.waitUntil(
    caches.open(CACHE).then(c=> c.addAll(SHELL).catch(()=>{/* einzelne Misses ignorieren */})).then(()=>self.skipWaiting())
  );
});

self.addEventListener("activate", e=>{
  e.waitUntil(
    caches.keys().then(keys=> Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())
  );
});

self.addEventListener("fetch", e=>{
  const url = new URL(e.request.url);
  if(e.request.method !== "GET") return;

  // TCGdex-API & Kartenbilder: immer Netzwerk versuchen, Cache als Fallback
  if(url.hostname.includes("tcgdex")){
    e.respondWith(
      fetch(e.request).then(res=>{
        const copy = res.clone();
        caches.open(CACHE).then(c=>c.put(e.request, copy)).catch(()=>{});
        return res;
      }).catch(()=> caches.match(e.request))
    );
    return;
  }

  // App-Shell: Cache zuerst, sonst Netzwerk
  e.respondWith(
    caches.match(e.request).then(hit=> hit || fetch(e.request).then(res=>{
      if(url.origin === location.origin){
        const copy = res.clone();
        caches.open(CACHE).then(c=>c.put(e.request, copy)).catch(()=>{});
      }
      return res;
    }).catch(()=> caches.match("./index.html")))
  );
});
